package com.alanger.ioquiero.views;

public class Configuracion {

    public static final String API_KEY = "AIzaSyBNAHJGZZE4hzvH5dHfHq3TOKe2HYP5Fks";

}
